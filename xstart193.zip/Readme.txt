xStarter for NT4.0/2000/XP/2003/Vista
Version 1.xx

Copyright (c) 2003-2009 xStarter Solutions, Inc.

WWW: http://www.xstarter.com
EMail: info@xstarter.com
_________________________________________________________________________________

1. About
2. General information
3. Install 
4. Purchasing 
5. Uninstall

1. ABOUT

The xStarter application is intended for automation of routine computer operations. 

2. GENERAL INFORMATION

Special features of the Program:
  * extended sheduler 
  * execution of tasks on system events 
  * user-friendly interface 
  * easily expandable set of automated operations 
  * internal Pascal-like language 
  * multilingual interface

3. INSTALL

The program is distributed in archive xstart1xx.zip. You can download it from developer site. There are three 
files inside archive xstart1xx.zip: Readme.txt, License.txt and Setup.exe. First of them contains brief information
about software features, the second is license agreement, and third is installation executable. 
For futher installation setup.exe must be started and setup instructions be processed.
There are "xStarter" folder will appear in Run->Programs after installation. That folder contains main program links.

4. PURCHASING

The program have NAG-screen reminder for registration. It will appear periodically while xStarter working.
For registration instractions see http://www.xstarter.com/order.html

5. UNINSTALL

Software deinstallation can be processed by standart Windows uninstall steps:
1) Run->Programs->xStarter->Uninstall.
or
2) Run->Programs->Control panel->Install and deinstall of software.
_________________________________________________________________________________

WWW: http://www.xstarter.com
EMail: info@xstarter.com
