If you have a license key you can place it in this folder.
