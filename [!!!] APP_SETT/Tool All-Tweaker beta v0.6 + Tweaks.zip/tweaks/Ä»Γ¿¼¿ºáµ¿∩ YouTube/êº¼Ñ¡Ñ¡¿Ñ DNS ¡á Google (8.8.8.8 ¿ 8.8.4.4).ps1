# Замените "Ethernet" на название вашего сетевого адаптера, если необходимо
$adapterName = "Ethernet"
$dns1 = "8.8.8.8"
$dns2 = "8.8.4.4"

Get-NetAdapter | Where-Object {$_.Name -like "*$adapterName*"} | Set-DnsClientServerAddress -ServerAddresses ($dns1, $dns2)

Write-Host "DNS изменен на Google"