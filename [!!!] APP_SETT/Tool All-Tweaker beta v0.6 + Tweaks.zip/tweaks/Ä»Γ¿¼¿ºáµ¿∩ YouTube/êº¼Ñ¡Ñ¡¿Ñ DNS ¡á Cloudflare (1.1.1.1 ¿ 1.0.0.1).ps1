# Замените "Ethernet" на название вашего сетевого адаптера, если необходимо
$adapterName = "Ethernet"
$dns1 = "1.1.1.1"
$dns2 = "1.0.0.1"

Get-NetAdapter | Where-Object {$_.Name -like "*$adapterName*"} | Set-DnsClientServerAddress -ServerAddresses ($dns1, $dns2)

Write-Host "DNS изменен на Cloudflare"