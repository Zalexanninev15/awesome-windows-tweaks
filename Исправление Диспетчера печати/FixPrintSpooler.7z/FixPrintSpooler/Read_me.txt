Author: BlueLife , Velociraptor
www.sordum.org

[010101010101010101]--Fix Print Spooler v1.3--[010101010101010101]

(Thursday, January 20, 2022)
------------
Changelog:
[ADDED] - Language support.
[ADDED] - Improvements have been made in coding

[010101010101010101]--Fix Print Spooler v1.2--[010101010101010101]

(Tuesday, July 27, 2021)
------------
Changelog:
[ADDED] - GUI
[ADDED] - Open Devices And Printers Button
[ADDED] - Disable Spooler Service
[ADDED] - x64 version
[ADDED] - Open Windows Services feature (Under Menu)
[ADDED] - Cmd Parameter Support
[FIXED] - If the spooler service was deleted, It doesn't work (spooler service will be checked and if Not exist will be recreated in the fix process)

[010101010101010101]--Fix Print Spooler v1.1--[010101010101010101]

(Tuesday , 23. April 2013)
------------
Changelog:
[FIXED] - A small Bug (Plus somecode Improvements)
NOTE: Exe version number has not been changed (Silent update)

[010101010101010101]--Fix Print Spooler v1.0--[010101010101010101]

(Thurstday, April 18, 2013)
------------
First release (It has No GUI) ; Fix Print Spooler is a Portable freeware Application , 
it can reset and clear the Print Spooler queue and "%systemroot%\System32\spool\printers\" folder 
then restarts the spooler service. If not, It will set the spooler service startup type to automatic, 
At the end of the process, It will give information next to the clock.

